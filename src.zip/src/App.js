import React from "react";
import Cards from "./utils/cards";

function App() {
  return (
    <div className="bg-blue-400 min-h-screen">
      
     
     <div className="grid grid-cols-3 grid-rows-3  min-h-screen gap-3">
    
      <div className="bg-white p-3 row-span-3 ">
        <Cards />
        
        <button  class="w-2/3 h-12 bg-slate-200 text-black rounded text shadow-xl ml-20 rounded-lg m-3">
        
          <h3>Home</h3>
        </button>
        <button  class="w-2/3 h-12  bg-slate-200 text-black rounded text shadow-xl ml-20 rounded-lg m-3">
          <h3>myBook</h3>
        </button>
        <button  class="w-2/3 h-12 bg-slate-200 text-black rounded text shadow-xl ml-20 rounded-lg m-3">
          <h3>myVid</h3>
        </button>
        <button  class="w-2/3 h-12  bg-slate-200 text-black rounded text shadow-xl ml-20 rounded-lg m-3">
          <h3>myIdea</h3>
        </button>
        <button  class="w-2/3 h-12  bg-slate-200 text-black rounded text shadow-xl ml-20 rounded-lg m-3">
          <h3>myJob</h3>
        </button>
        <button  class="w-2/3 h-12  bg-slate-200 text-black rounded text shadow-xl ml-20 rounded-lg m-3">
          <h3>myPodcast</h3>
        </button>
        <button  class="w-2/3 h-12  bg-slate-200 text-black rounded text shadow-xl ml-20 rounded-lg m-3">
          <h3>myReuse</h3>
        </button>
        <button  class="w-2/3 h-12  bg-slate-200 text-black rounded text shadow-xl ml-20 rounded-lg m-3">
          <h3>mySlowfood</h3>
        </button>
        <button  class="w-2/3 h-12  bg-slate-200 text-black rounded text shadow-xl ml-20 rounded-lg m-3">
          <h3>myCM</h3>
        </button>






        
      </div> 
     <div className="bg-slate-400 p-3 rounded ">
     
     
      

    
      </div> 
      <div className="bg-white p-3 rounded ">
        4
        
      </div> 
      <div className="bg-white p-3 rounded ">
        4
        
      </div> 
      <div className="bg-white p-3 rounded ">
        4
        
      </div> 
      {/* <div className="bg-blue-400 h-8 w-10">
      </div>  */}
     </div>
     </div>

    

);
  
}

export default App;
